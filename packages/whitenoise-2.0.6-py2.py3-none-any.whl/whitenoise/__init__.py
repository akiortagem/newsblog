from __future__ import absolute_import

from .base import WhiteNoise

__version__ = '2.0.6'

__all__ = ['WhiteNoise']
